/* The purpose of this file is to make Python use the C++ linker instead of
 * the standard C linker because igraph's core static library needs the C++
 * standard library */

