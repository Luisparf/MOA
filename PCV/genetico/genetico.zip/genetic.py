# -*- coding: utf-8 -*-
###########################################################################################
#                                                                                         #
#                Módulo que contém os algoritmos construtivos para o PCV                  #                          
#                                                                                         #      
###########################################################################################

from math import dist
from copy import deepcopy
# Uma cópia local de funções como essa reduz o tempo de execução

localLen = len
localDist = dist

def nearest(graph):
    # selected = randint(1, localLen(graph)-1)
    selected = 3

    first = selected

    walkWeight = 0
    walkedPath = []
    walkedPath.append(selected)
    graph[selected]['used'] = True

    while True:
        # Valor da distância entre nó atual e menor vizinho
        menor = float('inf')

        # Indice do menor vizinho encontrado
        menorIndex = -1

        # Conteiro para verificar se todos os vizinho já foram explorados
        endCounter = 0
        for i in range(1, localLen(graph)):
            # print("selected = {} i = {}".format(selected, i))

            if (i == selected) or (graph[i]['used']):
                endCounter += 1
                continue
            if dist([graph[selected]['x'], graph[selected]['y']], [graph[i]['x'], graph[i]['y']]) < menor:
                menor = dist([graph[selected]['x'], graph[selected]['y']], [graph[i]['x'], graph[i]['y']])
                menorIndex = i

        if endCounter == (localLen(graph) - 1):
            penultimo = localLen(walkedPath) - 1
            walkWeight += int(dist([graph[walkedPath[penultimo]]['x'], graph[walkedPath[penultimo]]['y']],
                                   [graph[first]['x'], graph[first]['y']]))
            walkedPath.append(first)
            break

        walkWeight += menor
        walkedPath.append(menorIndex)
        graph[menorIndex]['used'] = True
        selected = menorIndex

    # print(walkedPath)

    return walkedPath


###########################################################################################

def nearestneighbour(grafo, j):
    # selected = randint(1, localLen(graph)-1)
    selected = j
    first = selected

    walkedPath = [selected]
    grafo[selected]['used'] = True

    while True:
        # Valor da distância entre nó atual e menor vizinho
        menor = float('inf')

        # Indice do menor vizinho encontrado
        menor_index = -1

        # Conteiro para verificar se todos os vizinho já foram explorados
        end_counter = 0
        for i in range(1, localLen(grafo)):
            # print("selected = {} i = {}".format(selected, i))

            if (i == selected) or (grafo[i]['used']):
                end_counter += 1
                continue
            disti = localDist([grafo[selected]['x'], grafo[selected]['y']], [grafo[i]['x'], grafo[i]['y']])
            if disti < menor:
                menor = disti
                menor_index = i

        if end_counter == (localLen(grafo) - 1):
            walkedPath.append(first)
            break

        walkedPath.append(menor_index)
        grafo[menor_index]['used'] = True
        selected = menor_index

    # print(f'\nwalkedPath = {walkedPath}')

    return walkedPath


###########################################################################################

def genetic(graph, start_time, pop, mut, max_i, max_t, seed):

    population = []

    if pop > localLen(graph)-1:
        pop = localLen(graph) 

    # gerar população inicial 
    for i in range(1, pop ):
        population.append(nearestneighbour(deepcopy(graph),i))


    print(population)

