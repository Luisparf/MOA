def calculateDistance(x,y):
    print(x * y)